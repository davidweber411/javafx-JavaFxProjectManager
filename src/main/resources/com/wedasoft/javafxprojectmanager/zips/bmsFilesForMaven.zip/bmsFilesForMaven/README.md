# Description

A simple running JavaFX application template.

### Used technologies

| Technology    | Version       |
|---------------|---------------|
| JavaFX        | 17.0.8        |
| Maven         | Maven Wrapper |
| Module system | Non modular   |

### Features

| Feature              | Available                         |
|----------------------|-----------------------------------|
| Can create a fat JAR | Yes. Use the maven goal "package" |  
